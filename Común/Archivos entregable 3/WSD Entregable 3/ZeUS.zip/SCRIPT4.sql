--Caso de prueba 1. El cliente quiere realizar un evento. Todos los �tems y empelados est�n disponibles. Sueldo y precio de alquiler por d�a
--Carga de empleados
execute contratar_personal_almacen('Miguel L�pez','Mozo', 23, '28888888N', 954322222);
execute contratar_personal_tecnico('Manuel L�pez','JefeSonido', 23, '27888888N', 954322722);
execute contratar_personal_produccion('Miguel P�rez','JefeProduccion', 23, '26888888N', 954322822);
execute contratar_personal_comercial('Mart�n L�pez','Telefonista', 23, '25888888N', 954322922);

--Carga de �tems
execute agregar_altavoz('Electrovoice', 5, 21, 50, 12);